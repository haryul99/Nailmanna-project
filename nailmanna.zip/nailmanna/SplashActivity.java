package com.example.nailmanna;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class SplashActivity extends AppCompatActivity {
    TextView Title;
    Animation anim;
    @Override
    protected void onCreate(Bundle savedInstanceStare) {
        super.onCreate(savedInstanceStare);
        setContentView(R.layout.activity_splash);
        //lottie
        LottieAnimationView animationView = findViewById(R.id.splash);
        animationView.bringToFront();
        animationView.playAnimation();

        //Title
        Title = findViewById(R.id.Title);


        anim = new AlphaAnimation(0.0f,1.0f);
        anim.setDuration(1800);
        anim.setRepeatMode(Animation.REVERSE);


        Title.startAnimation(anim);


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
            }
        },1800);
    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
