package com.example.nailmanna;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kotlin.jvm.internal.CharSpreadBuilder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    Button btn_login;
    TextView btn_register2;
    EditText et_id, et_pass;
    private Context mContext;
    private CheckBox cb_save;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);
        mContext = this;
        btn_login = findViewById(R.id.btn_login);
        btn_register2 = findViewById(R.id.btn_register2);
        et_id = findViewById(R.id.et_id);
        et_pass = findViewById(R.id.et_pass);

        cb_save = (CheckBox) findViewById(R.id.cb_save);
        
//        et_id.setText("haryulpark");
//        et_pass.setText("@a37983705");

//        boolean boo = PreferenceManager.getBoolean(mContext,"check"); //로그인 정보 기억하기 체크 유무 확인
//        if(boo){ // 체크가 되어있다면 아래 코드를 수행
//            //저장된 아이디와 암호를 가져와 셋팅한다.
//            et_id.setText(PreferenceManager.getString(mContext, "id"));
//            et_pass.setText(PreferenceManager.getString(mContext, "pw"));
//            cb_save.setChecked(true); //체크박스는 여전히 체크 표시 하도록 셋팅
//        }

//        btn_login.setOnClickListener(new View.OnClickListener(){
//            public void onClick(View v){ //로그인 버튼 눌렀을 때 동작
//                //아이디 암호 입력창에서 텍스트를 가져와 PreferenceManager에 저장함
//                PreferenceManager.setString(mContext, "id", et_id.getText().toString()); //id라는 키값으로 저장
//                PreferenceManager.setString(mContext, "pw", et_pw.getText().toString()); //pw라는 키값으로 저장
//
//                Intent intent = new Intent(MainActivity.this, Parsing.class); //이건 없어도 무방
//                // 저장한 키 값으로 저장된 아이디와 암호를 불러와 String 값에 저장
//                String checkId = PreferenceManager.getString(mContext, "id");
//                String checkPw = PreferenceManager.getString(mContext, "pw");
//                //아이디와 암호가 비어있는 경우를 체크
//                if (TextUtils.isEmpty(checkId) || TextUtils.isEmpty(checkPw)){
//                    //아이디나 암호 둘 중 하나가 비어있으면 토스트메시지를 띄운다
//                    Toast.makeText(MainActivity.this, "아이디/암호를 입력해주세요",
//                            Toast.LENGTH_SHORT).show();
//                }else { //둘 다 충족하면 다음 동작을 구현해놓음
//                    intent.putExtra("id",checkId);
//                    intent.putExtra("pw",checkPw);
//                    startActivity(intent);
//                }
//            }
//        });
        //로그인 기억하기 체크박스 유무에 따른 동작 구현
//        cb_save.setOnClickListener(new CheckBox.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (((CheckBox)v).isChecked()) { // 체크박스 체크 되어 있으면
//                    //editText에서 아이디와 암호 가져와 PreferenceManager에 저장한다.
//                    PreferenceManager.setString(mContext, "id", et_id.getText().toString()); //id 키값으로 저장
//                    PreferenceManager.setString(mContext, "pw", et_pass.getText().toString()); //pw 키값으로 저장
//                    PreferenceManager.setBoolean(mContext, "check", cb_save.isChecked()); //현재 체크박스 상태 값 저장
//                } else { //체크박스가 해제되어있으면
//                    PreferenceManager.setBoolean(mContext, "check", cb_save.isChecked()); //현재 체크박스 상태 값 저장
//                    PreferenceManager.clear(mContext); //로그인 정보를 모두 날림
//                }
//            }
//        }) ;
        if(cb_save.isChecked()){
            SharedPreferences auto = getSharedPreferences("cb_save", MainActivity.MODE_PRIVATE);
            SharedPreferences.Editor autoLoginEdit = auto.edit();
            autoLoginEdit.putString("et_id", String.valueOf(et_id));
            autoLoginEdit.putString("et_pass", String.valueOf(et_pass));
            autoLoginEdit.commit();
        }

        btn_register2.setPaintFlags(btn_register2.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);




        // 회원가입 버튼 클릭
        btn_register2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
                overridePendingTransition(0, 0);
            }
        });

        // 로그인 버튼 클릭
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(et_id.getText().toString()) || TextUtils.isEmpty(et_pass.getText().toString())){

                    String message = "입력정보가 정확하지 않습니다";
                    Toast.makeText(MainActivity.this, message,Toast.LENGTH_SHORT).show();

                }else{
                    LoginRequest loginRequest = new LoginRequest();
                    //마지막 ID가지고 오기
                    commonData.getInstance().SetLastLoginID(et_id.getText().toString());

                    loginRequest.setUsername(et_id.getText().toString());
                    loginRequest.setPassword(et_pass.getText().toString());

                    loginUser(loginRequest);
                }


            }
        });

    }

    public void loginUser(LoginRequest loginRequest){
        Call<LoginResponse> loginResponseCall = ApiClient.getService().loginUser(loginRequest);
        loginResponseCall.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                if(response.isSuccessful()){
                    LoginResponse loginResponse = response.body();
                    Log.i("logcheck","response = "+response.body().getUsername());
                    Log.i("logcheck", "ID = "+loginResponse.getUsername());
                    Log.i("token insert before", "token ===="+loginResponse.getAccess());
                    //토큰 넣기

                    commonData.getInstance().setLastAccess(loginResponse.getAccess());
                    commonData.getInstance().SetLastLoginID( response.body().getUsername() );
                    commonData.getInstance().SetLastLoginNickname( loginResponse.getNickname() );

                    startActivity(new Intent(MainActivity.this, HomeActivity.class).putExtra("data", loginResponse));

                    finish();
                }else {
                    String message = "잘못된 아이디 혹은 비밀번호를 입력하셨습니다.";
                    Toast.makeText(MainActivity.this, message,Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {

                String message = t.getLocalizedMessage();
                Toast.makeText(MainActivity.this, message,Toast.LENGTH_SHORT).show();
            }
        });
    }

    // 내가 업로드한 파일
    public void MyUpload(String token){
        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://43.200.13.213:8000/like/")
                .addConverterFactory(GsonConverterFactory.create()).build();
        UserService userService = retrofit.create(UserService.class);
        String m_token = "Bearer "+token;
        Call<List<AddCustomerRes>> TestHeader = userService.MyUpload(m_token);
        Log.e("m_token cheak" , "====="+m_token);
        TestHeader.enqueue(new Callback< List<AddCustomerRes> >() {
            @Override
            public void onResponse(Call<List<AddCustomerRes>> call, Response<List<AddCustomerRes>> response) {
                if( response.isSuccessful() ){
                    int j = 0;
                    //정보 담을 배열 생성
                    HashMap<String, String> hashMap = new HashMap<>();
                    for(int i = 0; i < response.body().size(); i++ ){
                        Log.i("say first","============================================================================");
                        Log.i("say"," [ "+ i + " ] response myphototitle = "+ response.body().get(i).getMyphototitle()  );
                        Log.i("say"," [ "+ i + " ] response myphoto = "+ response.body().get(i).getMyphoto() );

                        hashMap.put(response.body().get(i).getMyphototitle(), "http://43.200.13.213:8000"+response.body().get(i).getMyphoto());
                    }
                    commonData.getInstance().SetPhotoInfo(hashMap);

                    //
                    for(Map.Entry<String, String> i : commonData.getInstance().GetPhotoInfo().entrySet() ){
                        Log.i("say", "PhotoTitle = [ "+ i.getKey() +"] Photo = [" + i.getValue() +"] ");
                    }

                }else {
                    Log.i("say","response nononono "+response.code());
                }
            }

            @Override
            public void onFailure(Call<List<AddCustomerRes>> call, Throwable t) {
                Log.i("say","failure" + t.getMessage());
            }
        });

    }


//    // 내가 좋아요 한 파일
//    public void LikePhoto(String token){
//        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://15.164.103.153:8000/like/")
//                .addConverterFactory(GsonConverterFactory.create()).build();
//        UserService userService = retrofit.create(UserService.class);
//        String l_token = "Bearer "+token;
//        Call<List<AddCustomerRes>> Likephoto = userService.LikePhoto(l_token);
//        Log.e("m_token cheak" , "====="+l_token);
//        Likephoto.enqueue(new Callback< List<AddCustomerRes> >() {
//            @Override
//            public void onResponse(Call<List<AddCustomerRes>> call, Response<List<AddCustomerRes>> response) {
//                if( response.isSuccessful() ){
//                    int j = 0;
//                    //정보 담을 배열 생성
//                    HashMap<String, String> hashMap = new HashMap<>();
//                    for(int i = 0; i < response.body().size(); i++ ){
//                        Log.i("say i like","============================================================================");
//                        Log.i("say"," [ "+ i + " ] response myphototitle = "+ response.body().get(i).getMyphototitle()  );
//                        Log.i("say"," [ "+ i + " ] response myphoto = "+ response.body().get(i).getMyphoto() );
//
//                        hashMap.put(response.body().get(i).getMyphototitle(), "http://15.164.103.153:8000"+response.body().get(i).getMyphoto());
//
//                        commonData.getInstance().SetMyPhotoTitle(response.body().get(2).getMyphototitle());
//                        commonData.getInstance().SetMyPhoto("http://15.164.103.153:8000"+response.body().get(2).getMyphoto());
//                        j = j + 1;
//                        System.out.println(j+ "입니다.");
//                    }
//                    commonData.getInstance().SetPhotoInfo(hashMap);
//
//                    //
//                    for(Map.Entry<String, String> i : commonData.getInstance().GetPhotoInfo().entrySet() ){
//                        Log.i("say", "PhotoTitle = [ "+ i.getKey() +"] Photo = [" + i.getValue() +"] ");
//                    }
//
//                }else {
//                    Log.i("say","response nononono "+response.code());
//                }
//            }
//            @Override
//            public void onFailure(Call<List<AddCustomerRes>> call, Throwable t) {
//                Log.i("say","failure" + t.getMessage());
//            }
//        });
//
//    }

}