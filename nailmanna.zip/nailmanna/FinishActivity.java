package com.example.nailmanna;

import android.animation.Animator;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FinishActivity extends AppCompatActivity {

    ImageView saveimage;
    ImageView MyPhoto;
    TextView wait, fi;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_finish);

        saveimage = (ImageView) findViewById(R.id.saveimage);
        ImageView shareButton = (ImageView) findViewById(R.id.shareButton);
        MyPhoto = (ImageView) findViewById(R.id.MyPhoto);
        wait = (TextView) findViewById(R.id.wait);
        fi = (TextView) findViewById(R.id.fi);

        LottieAnimationView animationView2 = findViewById(R.id.save);

//        Glide.with(FinishActivity.this).load(commonData.getInstance().GetMyPhoto()).into(MyPhoto);


        //갤러리 저장
        saveimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveToGallery();

                Toast.makeText(getApplicationContext(), "완료된 사진이 \"Nailmanna\" 파일에 저장 되었습니다. ", Toast.LENGTH_SHORT).show();

                animationView2.setVisibility(View.VISIBLE);
                animationView2.playAnimation();
            }
        });

        animationView2.addAnimatorListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                animationView2.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });

        // 한번 더 선택 시 activity 전환
        Button retry = (Button) findViewById(R.id.retry);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),DirectionActivity.class);
                startActivity(intent);
            }
        });

        // 홈으로 선택 시 activity 전환
        Button gohome = (Button) findViewById(R.id.gohome);
        gohome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),HomeActivity.class);
                startActivity(intent);
            }
        });

        // 네일북 ImageView 선택 시 activity 전환
        ImageView gosenailbook = (ImageView) findViewById(R.id.gosenailbook);
        gosenailbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),NailBookActivity.class);
                startActivity(intent);
            }
        });

        // 공유하기
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.setType("image/*");


                startActivity(Intent.createChooser(intent,null));
            }
        });

//        Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                finish();
//            }
//        }, 2000);



        ColorCu(commonData.getInstance().GetLastAccess(), commonData.getInstance().getColor1(), commonData.getInstance().getColor2(), commonData.getInstance().getColor3(), commonData.getInstance().getColor4(), commonData.getInstance().getColor5());
    }

    //이미지를 갤러리에 저장하는 함수 생성
    public void saveToGallery(){
        BitmapDrawable bitmapDrawable = (BitmapDrawable)MyPhoto.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        FileOutputStream outputStream = null;
        File file = Environment.getExternalStorageDirectory();
        File dir = new File(file.getAbsolutePath()+ "/Nailmanna");
        dir.mkdirs();

        String filename = String.format("%d.jpg", System.currentTimeMillis());
        File outFiles = new File(dir, filename);
        try{
            outputStream = new FileOutputStream(outFiles);
        }catch (Exception e){
            e.printStackTrace();
        }
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        try{
            outputStream.flush();
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            outputStream.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void ColorCu(String token, String col1, String col2, String col3, String col4, String col5){
        // timeout setting 해주기
        OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://43.200.13.213:8000/first/")
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create()).build();


        String m_token = "Bearer "+token;

        RequestBody color1 = RequestBody.create(MediaType.parse("multipart/form-data"), col1);
        RequestBody color2 = RequestBody.create(MediaType.parse("multipart/form-data"), col2);
        RequestBody color3 = RequestBody.create(MediaType.parse("multipart/form-data"), col3);
        RequestBody color4 = RequestBody.create(MediaType.parse("multipart/form-data"), col4);
        RequestBody color5 = RequestBody.create(MediaType.parse("multipart/form-data"), col5);

//        String color1 = "#001100";
//        String color2 = commonData.getInstance().getColor2();
//        String color3 = commonData.getInstance().getColor3();
//        String color4 = commonData.getInstance().getColor4();
//        String color5 = commonData.getInstance().getColor5();
        UserService userService = retrofit.create(UserService.class);

        Log.e("color1" , "===>"+color1);
        Call<ResponseBody> ColorCu = userService.ColorCu(m_token, color1, color2, color3, color4, color5);
        ColorCu.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if( response.isSuccessful() ){
                    Log.i("say", "Done");
                    // 완성 이미지 Set
                    wait.setVisibility(View.GONE);
                    fi.setVisibility(View.VISIBLE);

                    Glide.with(FinishActivity.this).load("http://43.200.13.213:8000/media/first/images/firstphotosave/result.png").apply(RequestOptions.skipMemoryCacheOf(true))
                            .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE)).into(MyPhoto);
                }else {
                    Log.i("say","response nononono "+response.code());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.i("say","failure " + t.getMessage());
            }
        });

    }

}
