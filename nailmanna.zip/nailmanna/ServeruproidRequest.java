package com.example.nailmanna;

public class ServeruproidRequest {

    private String user;
    private String my_photo_title;
    private String my_photo;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getMyphototitle() {
        return my_photo_title;
    }

    public void setMyphototitle(String my_photo_title) {
        this.my_photo_title = my_photo_title;
    }

    public String getMyphoto() {
        return my_photo;
    }

    public void setMyphoto(String my_photo) {
        this.my_photo = my_photo;
    }
}
