package com.example.nailmanna;

public class PreferenceManager {
}
