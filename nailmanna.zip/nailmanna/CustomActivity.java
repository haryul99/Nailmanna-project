package com.example.nailmanna;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import yuku.ambilwarna.AmbilWarnaDialog;

public class CustomActivity extends AppCompatActivity {
    // Nailcustom 화면

    // 무광 switch
    public TextView matte;
    // 큐빅 이동 code
    public enum TOUCH_MODE {
        NONE, //터치 안 했을 떄
        SINGLE, // 한 손가락 터치
        MULTI //두손가락 터치
    }
    private ImageView imageView;
    private TOUCH_MODE touchMode;

    private Matrix matrix; // 기존의 매트릭스
    private Matrix savedMatrix; // 작업 후 이미지에 매핑할 매트릭스
    private PointF startPoint; //한손가락 터치 이동 포인트
    private PointF midPoint; //두손가락 터치 시 중심 포인트
    private float oldDistance; //터치 시 두손가락 사이의 거리
    private double oldDegree = 0; // 두 손가락의 각도

    //nail image picture
    private ImageView t8dada8;
    private ImageView t89a1ad;
    private ImageView a8a5c4;
    private ImageView b78187;
    private ImageView cfb2a1;
    private ImageView da603f;
    private ImageView efca61;
    private ImageView e84f73;
    private ImageView dc7e76;

    //gucci
    private ImageView a6fa449;
    private ImageView a88c099;
    private ImageView ece7df;
    private ImageView ebafa5;
    private ImageView df675c;
    private ImageView a20005;
    private ImageView bl;

    //Leav
    private ImageView nail1;
    private ImageView nail2;
    private ImageView nail3;
    private ImageView nail4;
    private ImageView nail5;
    private ImageView nail6;
    private ImageView nail7;
    private ImageView nail8;
    private ImageView nail9;
    private ImageView nail10;

    //from
    private ImageView f1;
    private ImageView f2;
    private ImageView f3;
    private ImageView f4;
    private ImageView f5;
    private ImageView f6;
    private ImageView f7;
    private ImageView f8;
    private ImageView f9;



    // text view variable to set the color for GFG text
    private TextView gfgTextView;

    // two buttons to open color picker dialog and one to
    // set the color for GFG text
    private Button mSetColorButton, mPickColorButton;

    // view box to preview the selected color
    private View mColorPreview;

    // this is the default color of the preview box
    private int mDefaultColor;

    private HorizontalScrollView modi,gucci, leav, from;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_custom);


        modi = (HorizontalScrollView)findViewById(R.id.modi);
        gucci= (HorizontalScrollView)findViewById(R.id.gucci);
        leav = (HorizontalScrollView)findViewById(R.id.leav);
        from = (HorizontalScrollView)findViewById(R.id.from);

        //완료 선택 시 activity 전환
        Button done = (Button) findViewById(R.id.done);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(commonData.getInstance().GetLeftHand()==1){
                    Intent intent = new Intent(getApplicationContext(), SelecthandLeftActivity.class);
                    startActivity(intent);
                }else {
                    Intent intent = new Intent(getApplicationContext(), SelecthandActivity.class);
                    startActivity(intent);
                }
            }
        });

        ImageView modi_iv = (ImageView)findViewById(R.id.modi_iv);
        modi_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gucci.setVisibility(View.GONE);
                leav.setVisibility(View.GONE);
                from.setVisibility(View.GONE);
                modi.setVisibility(View.VISIBLE);
            }
        });

        ImageView gucci_iv = (ImageView)findViewById(R.id.gucci_iv);
        gucci_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modi.setVisibility(View.GONE);
                leav.setVisibility(View.GONE);
                from.setVisibility(View.GONE);
                gucci.setVisibility(View.VISIBLE);
            }
        });

        ImageView leav_iv = (ImageView)findViewById(R.id.leav_iv);
        leav_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modi.setVisibility(View.GONE);
                gucci.setVisibility(View.GONE);
                from.setVisibility(View.GONE);
                leav.setVisibility(View.VISIBLE);
            }
        });

        ImageView from_iv = (ImageView)findViewById(R.id.from_iv);
        from_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                modi.setVisibility(View.GONE);
                gucci.setVisibility(View.GONE);
                leav.setVisibility(View.GONE);
                from.setVisibility(View.VISIBLE);
            }
        });

        // 로딩화면 삽입

//        뷰페이저 기능 삭제 고려
//        pager=findViewById(R.id.pager);
//        pagerAdapter=new ScreeSlidePagerAdapter(this);
//        pager.setAdapter(pagerAdapter);



        //무광 스위치
//        matte = findViewById(R.id.matte);
//        SwitchCompat change_sw = findViewById(R.id.change_sw);
//
//        change_sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
//                if (isChecked){
//                    matte.setBackgroundColor(Color.parseColor("#1A000000"));
//                }else{matte.setBackgroundColor(Color.parseColor("#00000000"));}
//            }
//        });


        // 손 인식 Cubic crop

//        matrix = new Matrix();
//        savedMatrix = new Matrix();
//
//        imageView = findViewById(R.id.preview_selected_color);
//        imageView.setOnTouchListener(onTouch);
//        imageView.setScaleType(ImageView.ScaleType.MATRIX); // 스케일 타입을 매트릭스로 해줘야 움직인다.



        //colorpicker code

        //manicure image
        t89a1ad = findViewById(R.id.t89a1ad);
        a8a5c4 = findViewById(R.id.a8a5c4);
        t8dada8 = findViewById(R.id.t8dada8);
        b78187 = findViewById(R.id.b78187);
        cfb2a1 = findViewById(R.id.cfb2a1);
        da603f = findViewById(R.id.da603f);
        efca61 = findViewById(R.id.efca61);
        e84f73 = findViewById(R.id.e84f73);
        dc7e76 = findViewById(R.id.dc7e76);

        //gucci

        a6fa449 = findViewById(R.id.a6fa449);
        a88c099 = findViewById(R.id.a88c099);
        ece7df = findViewById(R.id.ece7df);
        ebafa5 = findViewById(R.id.ebafa5);
        df675c = findViewById(R.id.df675c);
        a20005 = findViewById(R.id.a20005);
        bl = findViewById(R.id.bl);

        nail1 = findViewById(R.id.nail1);
        nail2 = findViewById(R.id.nail2);
        nail3 = findViewById(R.id.nail3);
        nail4 = findViewById(R.id.nail4);
        nail5 = findViewById(R.id.nail5);
        nail6 = findViewById(R.id.nail6);
        nail7 = findViewById(R.id.nail7);
        nail8 = findViewById(R.id.nail8);
        nail9 = findViewById(R.id.nail9);
        nail10 = findViewById(R.id.nail10);

        f1 = findViewById(R.id.f1);
        f2 = findViewById(R.id.f2);
        f3 = findViewById(R.id.f3);
        f4 = findViewById(R.id.f4);
        f5 = findViewById(R.id.f5);
        f6 = findViewById(R.id.f6);
        f7 = findViewById(R.id.f7);
        f8 = findViewById(R.id.f8);
        f9 = findViewById(R.id.f9);


        // register the GFG text with appropriate ID
        gfgTextView = findViewById(R.id.gfg_heading);

        // register two of the buttons with their
        // appropriate IDs
        mPickColorButton = findViewById(R.id.pick_color_button);
        mSetColorButton = findViewById(R.id.set_color_button);

        // and also register the view which shows the
        // preview of the color chosen by the user
        mColorPreview = findViewById(R.id.preview_selected_color);

        // set the default color to 0 as it is black
        mDefaultColor = 0;

        // button open the AmbilWanra color picker dialog.
        mPickColorButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // to make code look cleaner the color
                        // picker dialog functionality are
                        // handled in openColorPickerDialogue()
                        // function
                        openColorPickerDialogue();
                    }
                });

        // button to set the color GFG text
        mSetColorButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // as the mDefaultColor is the global
                        // variable its value will be changed as
                        // soon as ok button is clicked from the
                        // color picker dialog.
                        gfgTextView.setTextColor(mDefaultColor);
                    }
                });


        t89a1ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(151,165, 173 ));
                commonData.getInstance().SetColorpick("#97a5ad");
                defcolorset();
            }
        });
        a8a5c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(172, 175, 223));
                commonData.getInstance().SetColorpick("#acafdf");
                defcolorset();
            }
        });
        t8dada8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(164, 186, 230));
                commonData.getInstance().SetColorpick("#a4bae6");
                defcolorset();
            }
        });
        b78187.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(221, 149 ,158 ));
                commonData.getInstance().SetColorpick("#dd959e");
                defcolorset();
            }
        });
        cfb2a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(213 ,163 ,140 ));
                commonData.getInstance().SetColorpick("#d5a38c");
                defcolorset();
            }
        });
        da603f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(217, 103 ,104));
                commonData.getInstance().SetColorpick("#d96768");
                defcolorset();
            }
        });
        efca61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(228 ,196 ,17 ));
                commonData.getInstance().SetColorpick("#e4c411");
                defcolorset();
            }
        });
        e84f73.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(220, 173, 202 ));
                commonData.getInstance().SetColorpick("#dcadca");
                defcolorset();

            }
        });
        dc7e76.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(171, 92, 82 ));
                commonData.getInstance().SetColorpick("#ab5c52");
                defcolorset();
            }
        });

        //gucci
        a6fa449.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(107, 130, 76));
                commonData.getInstance().SetColorpick("#6b824c");
                defcolorset();
            }
        });
        a88c099.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(157, 186, 166));
                commonData.getInstance().SetColorpick("#9dbaa6");
                defcolorset();
            }
        });
        ece7df.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(218, 222 ,218));
                commonData.getInstance().SetColorpick("#dadeda");
                defcolorset();
            }
        });
        ebafa5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(224, 184, 182));
                commonData.getInstance().SetColorpick("#e0b8b6");
                defcolorset();
            }
        });
        df675c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(239, 125, 102));
                commonData.getInstance().SetColorpick("#ef7d66");
                defcolorset();
            }
        });
        a20005.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(162, 30, 44 ));
                commonData.getInstance().SetColorpick("#a21e2c");
                defcolorset();
            }
        });
        bl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(2, 105, 169));
                commonData.getInstance().SetColorpick("#0269a9");
                defcolorset();
            }
        });

        nail1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-6674350);
                commonData.getInstance().SetColorpick(toRGBString(-6674350));
                defcolorset();
            }
        });
        nail2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-3842466);
                commonData.getInstance().SetColorpick(toRGBString(-3842466));
                defcolorset();
            }
        });
        nail3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-3112040);
                commonData.getInstance().SetColorpick(toRGBString(-3112040));
                defcolorset();
            }
        });
        nail4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-6058153);
                commonData.getInstance().SetColorpick(toRGBString(-6058153));
                defcolorset();
            }
        });
        nail5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-3891657);
                commonData.getInstance().SetColorpick(toRGBString(-3891657));
                defcolorset();
            }
        });
        nail6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-2310436);
                commonData.getInstance().SetColorpick(toRGBString(-2310436));
                defcolorset();
            }
        });
        nail7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-4884299);
                commonData.getInstance().SetColorpick(toRGBString(-4884299));
                defcolorset();
            }
        });
        nail8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-12974278);
                commonData.getInstance().SetColorpick(toRGBString(-12974278));
                defcolorset();
            }
        });
        nail9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-4494801);
                commonData.getInstance().SetColorpick(toRGBString(-4494801));
                defcolorset();
            }
        });
        nail10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(-13648991);
                commonData.getInstance().SetColorpick(toRGBString(-13648991));
                defcolorset();
            }
        });
        //from
        f1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(151, 104, 80));
                commonData.getInstance().SetColorpick("#976850");
                defcolorset();
            }
        });
        f2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(197, 111, 95));
                commonData.getInstance().SetColorpick("#c56f5f");
                defcolorset();
            }
        });
        f3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(186, 100, 85));
                commonData.getInstance().SetColorpick("#ba6455");
                defcolorset();
            }
        });
        f4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(202, 135, 129));
                commonData.getInstance().SetColorpick("#ca8781");
                defcolorset();
            }
        });
        f5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(198, 110, 96));
                commonData.getInstance().SetColorpick("#c66e60");
                defcolorset();
            }
        });
        f6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(197, 136, 129));
                commonData.getInstance().SetColorpick("#c58881");
                defcolorset();
            }
        });
        f7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(139, 77, 76));
                commonData.getInstance().SetColorpick("#8b4d4c");
                defcolorset();
            }
        });
        f8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(180, 96, 91));
                commonData.getInstance().SetColorpick("#b4605b");
                defcolorset();
            }
        });
        f9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mColorPreview.setBackgroundColor(Color.rgb(141, 58, 46));
                commonData.getInstance().SetColorpick("#8d3a2e");
                defcolorset();
            }
        });
    }
    // the dialog functionality is handled separately
    // using openColorPickerDialog this is triggered as
    // soon as the user clicks on the Pick Color button And
    // the AmbilWarnaDialog has 2 methods to be overridden
    // those are onCancel and onOk which handle the "Cancel"
    // and "OK" button of color picker dialog
    public void openColorPickerDialogue() {

        // the AmbilWarnaDialog callback needs 3 parameters
        // one is the context, second is default color,
        final AmbilWarnaDialog colorPickerDialogue = new AmbilWarnaDialog(this, mDefaultColor,
                new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                        // leave this function body as
                        // blank, as the dialog
                        // automatically closes when
                        // clicked on cancel button
                    }

                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        // change the mDefaultColor to
                        // change the GFG text color as
                        // it is returned when the OK
                        // button is clicked from the
                        // color picker dialog
                        toRGBString(color);
                        mDefaultColor = color;

                        // now change the picked color
                        // preview box to mDefaultColor
                        Log.e("color", ".>>>"+color);
                        Log.e("colorch", "====>"+toRGBString(color));

                        commonData.getInstance().SetColorpick(toRGBString(color));

                        for( int i = 1; i < 6 ; i++ ){
                            if( commonData.getInstance().GetSelectNo() == i ){
                                commonData.getInstance().SetHandColor(i,commonData.getInstance().GetColorpick());
                            }
                        }
                        //엄지를 선택할 경우
                        if( commonData.getInstance().GetSelectNo() == 1 ){
                            commonData.getInstance().setColor1(commonData.getInstance().GetColorpick());
                        }else if( commonData.getInstance().GetSelectNo() == 2 ){
                            commonData.getInstance().setColor2(commonData.getInstance().GetColorpick());
                        }else if( commonData.getInstance().GetSelectNo() == 3 ){
                            commonData.getInstance().setColor3(commonData.getInstance().GetColorpick());
                        }else if( commonData.getInstance().GetSelectNo() == 4 ){
                            commonData.getInstance().setColor4(commonData.getInstance().GetColorpick());
                        }else if( commonData.getInstance().GetSelectNo() == 5 ){
                            commonData.getInstance().setColor5(commonData.getInstance().GetColorpick());
                        }else if( commonData.getInstance().GetSelectNo() == 6 ) {
                            // 모두 동일 버튼을 선택 할 경우
                            commonData.getInstance().setColor1(commonData.getInstance().GetColorpick());
                            commonData.getInstance().setColor2(commonData.getInstance().GetColorpick());
                            commonData.getInstance().setColor3(commonData.getInstance().GetColorpick());
                            commonData.getInstance().setColor4(commonData.getInstance().GetColorpick());
                            commonData.getInstance().setColor5(commonData.getInstance().GetColorpick());
                        }

                        mColorPreview.setBackgroundColor(mDefaultColor);
                    }
                });
        colorPickerDialogue.show();
    }

        public void defcolorset(){

            for( int i = 1; i < 6 ; i++ ){
                if( commonData.getInstance().GetSelectNo() == i ){
                    commonData.getInstance().SetHandColor(i,commonData.getInstance().GetColorpick());
                }
            }
            //엄지를 선택할 경우
            if( commonData.getInstance().GetSelectNo() == 1 ){
                commonData.getInstance().setColor1(commonData.getInstance().GetColorpick());
            }else if( commonData.getInstance().GetSelectNo() == 2 ){
                commonData.getInstance().setColor2(commonData.getInstance().GetColorpick());
            }else if( commonData.getInstance().GetSelectNo() == 3 ){
                commonData.getInstance().setColor3(commonData.getInstance().GetColorpick());
            }else if( commonData.getInstance().GetSelectNo() == 4 ){
                commonData.getInstance().setColor4(commonData.getInstance().GetColorpick());
            }else if( commonData.getInstance().GetSelectNo() == 5 ){
                commonData.getInstance().setColor5(commonData.getInstance().GetColorpick());
            }else if( commonData.getInstance().GetSelectNo() == 6 ) {
                // 모두 동일 버튼을 선택 할 경우
                commonData.getInstance().setColor1(commonData.getInstance().GetColorpick());
                commonData.getInstance().setColor2(commonData.getInstance().GetColorpick());
                commonData.getInstance().setColor3(commonData.getInstance().GetColorpick());
                commonData.getInstance().setColor4(commonData.getInstance().GetColorpick());
                commonData.getInstance().setColor5(commonData.getInstance().GetColorpick());
            }
        }


        public String toRGBString(int color) {
            // format: #RRGGBB
            String red = Integer.toHexString(Color.red(color));
            String green = Integer.toHexString(Color.green(color));
            String blue = Integer.toHexString(Color.blue(color));

            if (red.length() == 1)
                red = "0" + red;
            if (green.length() == 1)
                green = "0" + green;
            if (blue.length() == 1)
                blue = "0" + blue;


            return "#" + red + green + blue;

        }//from w ww. j a  v  a  2 s . co  m



    // Cubic handle
//    private View.OnTouchListener onTouch = new View.OnTouchListener() {
//        @Override
//        public boolean onTouch(View v, MotionEvent event) {
//            if (v.equals(imageView)) {
//                int action = event.getAction();
//                switch (action & MotionEvent.ACTION_MASK) {
//                    case MotionEvent.ACTION_DOWN:
//                        touchMode = TOUCH_MODE.SINGLE;
//                        donwSingleEvent(event);
//                        break;
//                    case MotionEvent.ACTION_POINTER_DOWN:
//                        if (event.getPointerCount() == 2) { // 두손가락 터치를 했을 때
//                            touchMode = TOUCH_MODE.MULTI;
//                            downMultiEvent(event);
//                        }
//                        break;
//                    case MotionEvent.ACTION_MOVE:
//                        if (touchMode == TOUCH_MODE.SINGLE) {
//                            moveSingleEvent(event);
//                        } else if (touchMode == TOUCH_MODE.MULTI) {
//                            moveMultiEvent(event);
//                        }
//                        break;
//
//                    case MotionEvent.ACTION_UP:
//                    case MotionEvent.ACTION_POINTER_UP:
//                        touchMode = TOUCH_MODE.NONE;
//                        break;
//                }
//            }
//
//
//            return true;
//        }
//    };
//    private PointF getMidPoint(MotionEvent e) {
//
//        float x = (e.getX(0) + e.getX(1)) / 2;
//        float y = (e.getY(0) + e.getY(1)) / 2;
//
//        return new PointF(x, y);
//    }
//
//    private float getDistance(MotionEvent e) {
//        float x = e.getX(0) - e.getX(1);
//        float y = e.getY(0) - e.getY(1);
//        return (float) Math.sqrt(x * x + y * y);
//    }
//    private void donwSingleEvent(MotionEvent event) {
//        savedMatrix.set(matrix);
//        startPoint = new PointF(event.getX(), event.getY());
//    }
//    private void downMultiEvent(MotionEvent event) {
//        oldDistance = getDistance(event);
//        if (oldDistance > 5f) {
//            savedMatrix.set(matrix);
//            midPoint = getMidPoint(event);
//            double radian = Math.atan2(event.getY() - midPoint.y, event.getX() - midPoint.x);
//            oldDegree = (radian * 180) / Math.PI;
//        }
//    }
//    private void moveSingleEvent(MotionEvent event) {
//        matrix.set(savedMatrix);
//        matrix.postTranslate(event.getX() - startPoint.x, event.getY() - startPoint.y);
//        imageView.setImageMatrix(matrix);
//    }
//    private void moveMultiEvent(MotionEvent event) {
//        float newDistance = getDistance(event);
//        if (newDistance > 5f) {
//            matrix.set(savedMatrix);
//            float scale = newDistance / oldDistance;
//            matrix.postScale(scale, scale, midPoint.x, midPoint.y);
//
//            double nowRadian = Math.atan2(event.getY() - midPoint.y, event.getX() - midPoint.x);
//            double nowDegress = (nowRadian * 180) / Math.PI;
//            float degree = (float) (nowDegress - oldDegree);
//            matrix.postRotate(degree, midPoint.x, midPoint.y);
//
//
//            imageView.setImageMatrix(matrix);
//
//        }
//    }
}
