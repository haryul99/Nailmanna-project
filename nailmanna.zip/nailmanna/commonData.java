package com.example.nailmanna;


import java.util.ArrayList;
import java.util.HashMap;

public class commonData {
    private String LastImageURL = "";
    private String LastLoginID = "";
    private String LastLoginNickname = "";
    private String LastAccess = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjUyOTQwMTI0LCJpYXQiOjE2NTI4NTM3MjQsImp0aSI6IjNiZjgyMzIyNWVmYTQxMzJiZjgyNWFkMzNkYWFkYzZjIiwidXNlcl9pZCI6Mn0.OT-ElZRAqNkJbnUTR8I6voIOPlFmWpC7mdeLr4ffJzw";
    private String My_Photo="";
    private String My_Photo_Title="";
    private int LeftHand=0;
    private String Re_Photo_Title="";
    private String Colorpick="";

    private String color1 ="";
    private String color2 ="";
    private String color3 ="";
    private String color4 ="";
    private String color5 ="";

    public String getColor1() {
        return color1;
    }

    public void setColor1(String color1) {
        this.color1 = color1;
    }

    public String getColor2() {
        return color2;
    }

    public void setColor2(String color2) {
        this.color2 = color2;
    }

    public String getColor3() {
        return color3;
    }

    public void setColor3(String color3) {
        this.color3 = color3;
    }

    public String getColor4() {
        return color4;
    }

    public void setColor4(String color4) {
        this.color4 = color4;
    }

    public String getColor5() {
        return color5;
    }

    public void setColor5(String color5) {
        this.color5 = color5;
    }

    public int GetLeftHand() { return LeftHand; }
    public void SetLeftHand(int LeftHand) { this.LeftHand = LeftHand;}



    private int SelectNo= 0 ;


    private HashMap<String, String> My_Photo_info = null;

    private HashMap<String, String> My_Photo_Like = null;

    private HashMap<String, String> My_Photo_Made = null;

    private ArrayList<Integer> LikeCount = null;

    private HashMap<Integer, Integer> HandSelect = null;
    HashMap hashMap = new HashMap<Integer, Integer>();

    private HashMap<Integer, String> HandColor = null;
    HashMap handMap = new HashMap<Integer, String>();

    public void SetLastImageURL(String url){
        this.LastImageURL = url;
    }
    public String GetLastImageURL(){
        return LastImageURL;
    }

    public void SetLastLoginNickname(String nickname){ this.LastLoginNickname = nickname; }
    public String GetLastLoginNickname(){ return LastLoginNickname; }

    public void SetMyPhoto(String My_Photo) { this.My_Photo = My_Photo;}
    public String GetMyPhoto() { return My_Photo;}

    public void SetMyPhotoTitle (String My_Photo_Title) { this.My_Photo_Title = My_Photo_Title;}
    public String GetMyPhotoTitle() { return My_Photo_Title;}

    public void SetRePhotoTitle (String Re_Photo_Title ) { this.Re_Photo_Title = Re_Photo_Title; }
    public String GetRePhotoTitle() { return Re_Photo_Title; }

    public void SetLastLoginID(String ID){ this.LastLoginID = ID; }
    public String GetLastLoginID(){ return LastLoginID; }

    public void setLastAccess(String access){ this.LastAccess = access;}
    public String GetLastAccess(){ return LastAccess;}

    public void SetColorpick(String Colorpick){ this.Colorpick = Colorpick; }
    public String GetColorpick() { return Colorpick; }

    public void SetPhotoInfo(HashMap<String, String> hashMap ) {this.My_Photo_info = hashMap; }
    public HashMap<String, String> GetPhotoInfo(){ return My_Photo_info; }


    public void SetPhotoLike(HashMap<String, String> hashMap ) { this.My_Photo_Like = hashMap; }
    public HashMap<String, String> GetPhotoLike(){ return My_Photo_Like; }

    public void SetPhotoMade(HashMap<String, String> hashMap ) { this.My_Photo_Made = hashMap; }
    public HashMap<String, String> GetPhotoMade(){ return My_Photo_Made; }

    public void SetLikeCount(ArrayList<Integer> arrayList) { this.LikeCount = arrayList; }
    public ArrayList<Integer> GetLikeCount() { return LikeCount; }

    public void SetHandSelect(int key, int v) {
        hashMap.put(key, v);
        this.HandSelect = hashMap; }

    public Integer GetHandSelect(int key) { return HandSelect.get(key); }

    public void SetHandColor(int key, String v){
        handMap.put(key, v);
        this.HandColor = handMap; }
    //int key를 매개변수로 넣어서 해당 키에 맞는 velue를 return
    public String GetHandColor(int key) { return HandColor.get(key); }

    public HashMap<Integer, String> Getserversand(){ return HandColor; }

    public void SetSelectNo(int SelectNo) { this.SelectNo = SelectNo;}
    public int GetSelectNo() { return SelectNo;}


    private static commonData instance = null;

    public static synchronized commonData getInstance(){
        if(null == instance){
            instance = new commonData();
        }
        return instance;
    }

}
